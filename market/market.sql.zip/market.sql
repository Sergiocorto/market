-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 02 2021 г., 21:59
-- Версия сервера: 10.4.13-MariaDB
-- Версия PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `market`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `name`, `createdAt`, `updatedAt`) VALUES
(1, 'Футболки', '2021-03-13 18:14:22', '2021-03-13 18:14:22'),
(2, 'Брюки', '2021-03-13 18:33:06', '2021-03-13 18:33:06'),
(12, 'Обувь', '2021-04-02 11:54:03', '2021-04-02 11:54:03');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `cost` double NOT NULL,
  `image` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `title`, `description`, `cost`, `image`, `createdAt`, `updatedAt`) VALUES
(14, 1, 'Футболка New Balance', 'Футболка New Balance Athletics Varsity MT03517VGN', 634, '02042021-170859_060-gGmqrW1mdS725AG5yliud2X9C6pRATZc36PSbDt8.jpeg', '2021-04-02 14:08:59', '2021-04-02 14:08:59'),
(15, 1, 'Поло Fila', 'Поло Fila 104709-B2', 524, '02042021-171051_430-F2A3ZjVrMrTR8DCShwVczARTtdq5oGNm6WjERjBl.jpeg', '2021-04-02 14:10:51', '2021-04-02 14:10:51'),
(16, 1, 'Футболка Puma', 'Футболка Puma Essentials Tee 85174103 S Medium Gray Heather', 632, '02042021-171151_219-lZgLXn397Pn2f1NOR6U5jAnAFHrEFZE6FavgYIoe.jpeg', '2021-04-02 14:11:51', '2021-04-02 14:11:51'),
(17, 1, 'Футболка Lacoste', 'Футболка Lacoste TH2090-AU8 (T4)', 1910, '02042021-171310_460-u2QGkvegzSOJjsqrHMkmILv27ZMsZAglmiWq0gtr.jpeg', '2021-04-02 14:13:10', '2021-04-02 14:13:10'),
(18, 2, 'Штани BEZET', 'Штани BEZET Basic \'19 0574 M Khaki', 669, '02042021-171753_222-bezet_roz6206102006.jpg', '2021-04-02 14:17:53', '2021-04-02 14:17:53'),
(19, 2, 'Джинси Remix', 'Джинси Remix 9007 38 Темно-сині', 875, '02042021-171949_932-remix_2950006535380_images_18753880051.jpg', '2021-04-02 14:19:49', '2021-04-02 14:19:49'),
(20, 2, 'Штани-карго BEZET', 'Штани-карго BEZET Aggressive 2.0 Black\'21 1402 XS Чорні', 719, '02042021-172055_650-bezet_roz6400032635_images_21856132958.jpg', '2021-04-02 14:20:55', '2021-04-02 14:20:55'),
(21, 12, 'Туфлі ECCO', 'Туфлі ECCO 42053451707 45 Чорні', 4999, '02042021-172833_622-ECCO_194890082182_images_21664677958.jpg', '2021-04-02 14:28:33', '2021-04-02 14:28:33'),
(22, 12, 'Туфлі ECCO', 'Туфлі ECCO Vitrus Iii 640504 (01482) 43 Коричневі', 4999, '02042021-172926_377-ecco_809704833651_images_14039542206.jpg', '2021-04-02 14:29:26', '2021-04-02 14:29:26'),
(23, 12, 'Туфлі ECCO', 'Туфлі ECCO 42054451327 45 Сірі', 3999, '02042021-173020_300-ECCO_737428617649_images_21664688283.jpg', '2021-04-02 14:30:20', '2021-04-02 14:30:20');

-- --------------------------------------------------------

--
-- Структура таблицы `session`
--

CREATE TABLE `session` (
  `sid` varchar(36) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `session`
--

INSERT INTO `session` (`sid`, `expires`, `data`, `createdAt`, `updatedAt`) VALUES
('plbiDLFXZ-pf7HdKgM906DN2Dcwi-GkS', '2021-04-03 19:57:33', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"user\":{\"id\":2,\"name\":null,\"email\":\"sergio@mail.com\",\"password\":\"$2a$10$Qe8HaWosAYVRs8E/d9btYuCqw133T9phZcqr8LrqOi4NsxKtRgZte\",\"isAdmin\":false,\"createdAt\":\"2021-03-17T07:55:07.000Z\",\"updatedAt\":\"2021-03-17T07:55:07.000Z\"},\"isAuthenticate\":true,\"basket\":[{\"id\":14,\"category_id\":1,\"title\":\"Футболка New Balance\",\"description\":\"Футболка New Balance Athletics Varsity MT03517VGN\",\"cost\":634,\"image\":\"02042021-170859_060-gGmqrW1mdS725AG5yliud2X9C6pRATZc36PSbDt8.jpeg\",\"createdAt\":\"2021-04-02T14:08:59.000Z\",\"updatedAt\":\"2021-04-02T14:08:59.000Z\",\"count\":2},{\"id\":15,\"category_id\":1,\"title\":\"Поло Fila\",\"description\":\"Поло Fila 104709-B2\",\"cost\":524,\"image\":\"02042021-171051_430-F2A3ZjVrMrTR8DCShwVczARTtdq5oGNm6WjERjBl.jpeg\",\"createdAt\":\"2021-04-02T14:10:51.000Z\",\"updatedAt\":\"2021-04-02T14:10:51.000Z\",\"count\":3},{\"id\":14,\"category_id\":1,\"title\":\"Футболка New Balance\",\"description\":\"Футболка New Balance Athletics Varsity MT03517VGN\",\"cost\":634,\"image\":\"02042021-170859_060-gGmqrW1mdS725AG5yliud2X9C6pRATZc36PSbDt8.jpeg\",\"createdAt\":\"2021-04-02T14:08:59.000Z\",\"updatedAt\":\"2021-04-02T14:08:59.000Z\",\"count\":\"1\"},{\"id\":16,\"category_id\":1,\"title\":\"Футболка Puma\",\"description\":\"Футболка Puma Essentials Tee 85174103 S Medium Gray Heather\",\"cost\":632,\"image\":\"02042021-171151_219-lZgLXn397Pn2f1NOR6U5jAnAFHrEFZE6FavgYIoe.jpeg\",\"createdAt\":\"2021-04-02T14:11:51.000Z\",\"updatedAt\":\"2021-04-02T14:11:51.000Z\",\"count\":\"1\"}]}', '2021-04-02 19:55:14', '2021-04-02 19:57:33');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `isAdmin`, `createdAt`, `updatedAt`) VALUES
(1, NULL, 'admin@mail.com', '$2a$10$9jgmObn59ArBzC17qsuBy.OWp2jR.xQmNHizY9ELPfn4n2j3vyB5K', 1, '2021-03-17 07:53:57', '2021-03-17 07:53:57'),
(2, NULL, 'sergio@mail.com', '$2a$10$Qe8HaWosAYVRs8E/d9btYuCqw133T9phZcqr8LrqOi4NsxKtRgZte', 0, '2021-03-17 07:55:07', '2021-03-17 07:55:07');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`sid`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
